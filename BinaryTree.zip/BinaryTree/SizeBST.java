package sizebst;


/**
 * Class SizeBST represents a Binary Search Tree that can also be used, for any integer j,
 *  to answer the question "how many numbers in the tree are less than or equal to j" in worst 
 *  case time h where h is the height of the tree (not the number of nodes).
 * 
 *  The actual nodes of the tree are of class SizeBSTN.  SizeBST represents the overall tree.
 *  IF instance variable rootNode is null, the tree is empty, otherwise rootNode is the root
 *  of the tree of SizeBSTN's
 * @author lou
 *
 */
public class SizeBST {
	SizeBSTN rootNode;

	public SizeBST(SizeBSTN root){
		rootNode =  root;
	}
	
	public String toString(){
		if (rootNode == null)
			return "(null)";
		else {
			return "("+ rootNode.toString() + ")";
		}
	}
	
	/**
	 * @param target the number to search for
	 * @return true if target is in this tree
	 */
	public boolean search(int target){

		 if(rootNode == null){
	            
	            return false;
	        }
		 else{
			 
			 SizeBSTN Current = rootNode;			 
	           while(Current != null){
	               
	                if(target > Current.data){
	                    Current = Current.RSubtree;
	                }else if (target < Current.data){
	                    Current = Current.LSubtree;
	                }
	                else{
	                	return true;
	                }
	            }
	            
	             
	          
	        }
	        
	    
		
		return false; // replace this line
	}
	
	/**
	 * insert newData into tree;  if already there, do not change tree
	 * @param newData int to insert
	 */
  	public void insert(int newData){ 
  		
  		if(search(newData)==true){
  			return;
  		}
  		
  		
  		SizeBSTN NewNode= new SizeBSTN(newData); 
		//SizeBSTN Left= new SizeBSTN(rootNode.LSubtree.data);
		//SizeBSTN Right= new SizeBSTN(rootNode.RSubtree.data);
		//boolean inserted=false;
  		
		 if(rootNode == null){
        		
	            rootNode = NewNode;
	            return;
	        }
		 else{

			 
			 SizeBSTN Current = rootNode;
			 SizeBSTN BeforeCurrent=null;
	       rootNode.getNodeIncr(newData);

	           while(Current != null){
	        	   BeforeCurrent = Current;
	               
	                if(newData > Current.data){
	                    Current = Current.RSubtree;
	                }else{
	                    Current = Current.LSubtree;
	                }
	            }

	             
	            if(newData > BeforeCurrent.data){
	            	BeforeCurrent.RSubtree = NewNode;
	            }
	            else {
	            	BeforeCurrent.LSubtree = NewNode;
	            }


	        }
	        return;
	    }
		
		// fill in here
	
	
	/**
	 * @return returns how many numbers in the tree are less than or equal to target.  Returns -1 if tree is empty
	 * @param target
	 */
  	private int Numleq(int target, SizeBSTN root){
  		int count=0; // our actual node
  		if (root.data<=target){
		        count +=1;
		    	}
  			    if(root.LSubtree != null){
  			    	
  			        count+=Numleq(target, root.LSubtree);
  			    }
  			    if(root.RSubtree != null){
  			    	
  			        count+= Numleq(target,root.RSubtree);
  			    }

  			    return count;
  	}
  	
  	
	public int numLEq(int target){
		
		if (rootNode==null){
			return -1;
		}
		
		return Numleq(target,rootNode);
	}
	
	public static void main(String args []){
		SizeBST tree1 = new SizeBST(null);
		
		System.out.println("empty: "+tree1);
		tree1.insert(40);
		tree1.insert(20);
		tree1.insert(60);
		tree1.insert(50);
		tree1.insert(55);
		tree1.insert(10);
		tree1.insert(30);
		tree1.insert(53);
		
		
		
		

		
		System.out.println("40 "+tree1);
		//System.out.println("The node "+tree1.rootNode.getNode(20)+"is 20 or node the 20 will point to 20");

		//System.out.println("The tree contains 32: "+tree1.search(32));
		//System.out.println("The tree contains "+tree1.numLEq(39)+" nodes <= to 39");
		// add any test code you want here - this is not graded
		}

	
}
