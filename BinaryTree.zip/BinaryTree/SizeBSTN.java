package sizebst;

/**
 * Instances of class SizeBSTN are Nodes of the Size Binary Search Tree 
 * @author lou
 *
 */
public class SizeBSTN {
	SizeBSTN LSubtree;  // left subtree of this tree (may be null)
	SizeBSTN RSubtree;  // right subtree of this tree (may be null)
	int data; // data at this node of the tree
	int size; // number of tree entries that are less than or equal to data

/**
 * create a new leaf of the tree with the given data
 * @param data
 */
	public SizeBSTN(int data){
		LSubtree = null;
		RSubtree = null;
		this.data = data;
		size = 1;
	}
	
	/* see assignment for proper format for toString
	 */
	
	public String toString(){
			String Left = "";
	       String Right = "";
	       String string= "";
	       if (LSubtree != null){ Left =  LSubtree.toString();}

	      else{ Left = null;}

	       if (RSubtree != null){ Right = RSubtree.toString();}

	       else {Right = null;}
	       
	       string = "[ "+Left + " " +data+"," +size+ " " +Right+ " ]";
	       return string;

 }
 
	
	
	/**
	 * search for the number target in this tree
	 * @param target number to search for
	 * @return either the node that holds target,
	 * if there is one, or the node which should point to the node that 
	 * will hold target if it is added now  
	 */
	private SizeBSTN getNodeB(int target, SizeBSTN rootNode){
		 if(rootNode == null){
	            return rootNode;
	        }
		 else{
			 SizeBSTN Current = rootNode;
			 SizeBSTN BeforeCurrent=null;
			 
	           while(Current != null){
	        	   BeforeCurrent = Current;
	               
	                if(target > Current.data){
	                    Current = Current.RSubtree;
	                }
	                else if(target<Current.data) {
	                    Current = Current.LSubtree;
	                }
	                else{
	                	return Current;
	                }
	            }
	            
	            return BeforeCurrent;

	        }
	       
		
	
	}
	
	public SizeBSTN getNode(int target){
		SizeBSTN Root = this;

		return getNodeB(target,Root);
	}
	
	/**
	 * like getNode but increments size fields as appropriate
	 * @param target number to search for
	 */
	private void getSize(int target, SizeBSTN Root){
		
		
		if ((target < Root.data) && (Root.LSubtree == null) ) {
			if (Root.LSubtree == null){
		         Root.size++;

			}
			
	     }
		
		if( (target < Root.data && (!(Root.equals(getNode(target))))) ){
			
			if (Root.LSubtree != null){ 
				
				Root.size++;
				Root=Root.LSubtree;
		         getSize(target,Root);

				}  
	     }
		
		if ((Root.RSubtree != null) ){
			if (target > Root.data){
				
				 Root=Root.RSubtree;
		         getSize(target,Root);

			}
	    	
	     }
		
	
	      
	}
	
	public void getNodeIncr(int target){
		SizeBSTN Current = this;
		getSize(target, Current);
		
		// fill in here
	}
	
	/**
	 * actually calculates number of numbers <= target.  
	 * Does search for target like getNode but adds up 
	 * the size fields of all nodes whose data is <= target.
	 * @return the number of nodes in this tree with data <= target
	 */
	
	
	private int NodeSum(int target, SizeBSTN root){
		int count=0; // our actual node
  		if (root.data<=target){
		        count +=root.size;
		    	}
  			    if(root.LSubtree != null){
  			    	
  			        count+=NodeSum(target, root.LSubtree);
  			    }
  			    if(root.RSubtree != null){
  			    	
  			        count+= NodeSum(target,root.RSubtree);
  			    }

  			    return count;
	}
	public int getNodeSum(int target){
		SizeBSTN Current = this;
		return NodeSum(target,Current);
		
		

	}
	
	
}	

