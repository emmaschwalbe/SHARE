	package webSearch;
	import readFile.*;
	import java.io.*;
	import java.util.ArrayList;
	import java.util.LinkedList;

	public class Digraph {
		 ArrayList<ArrayList> Graph = new ArrayList<ArrayList>();
		 ArrayList<LinkedList> adjacency= new ArrayList<LinkedList>();
		 ArrayList<String> Title = new ArrayList<String>();
		 ArrayList<LinkedList> Keys = new ArrayList<LinkedList>();

		public static void main(String[] args) {
			// TODO Auto-generated method stub
			//Digraph graph =new Digraph();
		
		}
	

		public Digraph(ReadFile Rdfile){
			
	
			
			for(int v=0 ; v<Rdfile.getNumberOfWebpages(); v++){
				 LinkedList edges = new LinkedList();
				 edges.addAll(Rdfile.getOutLinks(v));
				 //need to put edges into adjacency 
				 adjacency.add(edges); 

				 
			}//end of for loop
			
			//System.out.println("graph"+adjacency);

			
			for(int t=0 ; t<Rdfile.getNumberOfWebpages(); t++){
				Title.add(Rdfile.getPageTitle(t));
			}
			//System.out.println("Titles"+Title);

			for(int v=0 ; v < Rdfile.getNumberOfWebpages() ; v++){
				 LinkedList Key = new LinkedList();
				 Key.addAll(Rdfile.getKeyPhrases(v));
				// System.out.println(edges);
				 //need to put edges into adjacency 
				 Keys.add(Key); 

				 
			}//end of for loop
			//System.out.println("KeyPhrases"+Keys);

			Graph.add(adjacency);
			Graph.add(Title);
			Graph.add(Keys);
			//System.out.print(Graph);
			
			
			// System.out.println(adjacency);

		}//end of Digraph skeleton
		
		public ArrayList<ArrayList> getGraph(){
			return Graph;
		}
		
		public ArrayList<LinkedList> getAdj(){
			return adjacency;
		}
		
		public ArrayList<String> getTitle(){
			return Title;
		}
		
		public ArrayList<LinkedList> getKeys(){
			return Keys;
		}
		
	/*public ArrayList<ArrayList> getGraph(){
		return Graph;
		}
	*/

	

}
